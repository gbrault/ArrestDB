/**
 * Copyright (c) 2016, Gilbert Brault. All rights reserved.
 *
 * ckrlite plugin (widget to display database chuncks)
 *
 */
 /**
 * to do
 * use PubSub as the update communication vector for parameterized query
 */
// Register the plugin within the editor.
CKEDITOR.plugins.add('ckrlite', {
    // This plugin requires the Widgets System defined in the 'widget' and the 'ajax' plugins.
    requires: 'widget,restajax',
    
    // Register the icon used for the toolbar button. It must be the same
    // as the name of the widget.
    icons: 'ckrlite',

    // The plugin initialization logic goes inside this method.
    init: function(editor) {
        // Register the editing dialog.
        CKEDITOR.dialog.add('ckrlite', this.path + 'dialogs/ckrlite.js'); 
        
        // Register the ckrlite widget.
        editor.widgets.add('ckrlite', {
            // Allow all HTML elements, classes, and styles that this widget requires.
            // Read more about the Advanced Content Filter here:
            // * http://docs.ckeditor.com/#!/guide/dev_advanced_content_filter
            // * http://docs.ckeditor.com/#!/guide/plugin_sdk_integration_with_acf
            allowedContent: 'div(!ckrlite,align-left,align-right,align-center)[!data-name]{width};' + 
            'div(!ckrlite-rendered)[title];',
            
            // Minimum HTML which is required by this widget to work.
            requiredContent: 'div(ckrlite)',
            
            // Define a nested editable area.
            editables: {
                rendered: {
                    selector:  '.ckrlite-rendered',
                    allowedContent: 'tr td[data-cell] p b br ul li ol strong em i;'+'table[csqlite-render]'   
                }
            },
            
            // Define the template of a new Sqlite widget.
            // The template will be used when creating new instances of the Simple Box widget.
            template: '<div class="ckrlite" title="Arrest DB Widget">' + 
            '<div class="ckrlite-rendered" title="rendered Data"><p>Content...</p></div>' + 
            '</div>',
            
            // Define the label for a widget toolbar button which will be automatically
            // created by the Widgets System. This button will insert a new widget instance
            // created from the template defined above, or will edit selected widget
            // (see second part of this tutorial to learn about editing widgets).
            //
            // Note: In order to be able to translate your widget you should use the
            // editor.lang.ckrlite.* property. A string was used directly here to simplify this tutorial.
            button: 'Sqlite Query Editor',
            
            // Set the widget dialog window name. This enables the automatic widget-dialog binding.
            // This dialog window will be opened when creating a new widget or editing an existing one.
            dialog: 'ckrlite',
            
            // Check the elements that need to be converted to widgets.
            //
            // Note: The "element" argument is an instance of http://docs.ckeditor.com/#!/api/CKEDITOR.htmlParser.element
            // so it is not a real DOM element yet. This is caused by the fact that upcasting is performed
            // during data processing which is done on DOM represented by JavaScript objects.
            upcast: function(element) {
                // Return "true" (that element needs to converted to a Simple Box widget)
                // for all <div> elements with a "ckrlite" class.
                return element.name == 'div' && element.hasClass('ckrlite');
            },
            /* get called before the edit dialog is open
            edit: function(evt){
                
            },
            */
            // When a widget is being initialized, we need to read the data 
            // from DOM and set it by using the widget.setData() method.
            // More code which needs to be executed when DOM is available may go here.
            init: function() {
               // the following 4 lines must be at the bigenning of init function
                // makes sure we can reference widget from the nested editable
                this.editables.rendered.widget = this;
                // attach the PubSub Communication Object to this widget
                this.PubSub = this.editor.window.PubSub;       
                // let the other parameters as they are...
                // Other parameters
                var width = this.element.getStyle('width');
                if (width)
                    this.setData('width', width);
                
                if (this.element.hasClass('align-left'))
                    this.setData('align', 'left');
                if (this.element.hasClass('align-right'))
                    this.setData('align', 'right');
                if (this.element.hasClass('align-center'))
                    this.setData('align', 'center');
               
            },
            
            // Listen on the widget#data event which is fired every time the widget data changes
            // and updates the widget's view.
            // Data may be changed by using the widget.setData() method, used in the widget dialog window.			
            data: function() {
                this.refresh();
                // positionning
                if (this.data.width == '')
                    this.element.removeStyle('width');
                else
                    this.element.setStyle('width', this.data.width);
                
                // Brutally remove all align classes and set a new one if "align" widget data is set.
                this.element.removeClass('align-left');
                this.element.removeClass('align-right');
                this.element.removeClass('align-center');
                if (this.data.align)
                    this.element.addClass('align-' + this.data.align);
            },
            refresh: function(){
                // SQL data
                var format = this.editor.ckrlite[this.data.name].format; // this.data.format;
                var content = this.editor.ckrlite[this.data.name].content; // this.data.content;
                var template = this.editor.ckrlite[this.data.name].template; // this.data.template;
                var rendered = this.render(format,content,template);
                // this.element.setAttribute('data-rendered',rendered);
                this.editor.ckrlite[this.data.name].rendered=rendered;
                // this.setData('rendered', rendered);
                this.editables.rendered.setHtml(rendered);                        
            },
            render: function(format, content, template){
              // with filtered data and template issue the html patch
              var i,j;
              if((format==null)||(content==null)||(template==null)) return "";
              var formatList = JSON.parse(format);              
              var content = JSON.parse(content);
              var out = this.formatData(content,format);
              var output='<table class="ckrlite-render">';
              /*
              for(i=0; i<content.length;i++){
                 var rendered_template = template;
                 rendered_template=rendered_template.replace(new RegExp('\\$row\\$','g'),""+i);
                 for(j=0;j<formatList.length;j++){
                    var r = new RegExp("\\$"+formatList[j].variable+"\\$",'i');
                    rendered_template = rendered_template.replace(r,out[i][formatList[j].variable]);
                 }
                 output += rendered_template;
              }*/
              var tokenizer = new Tokenizer([/\$(\w+)\$/],function( src, real, re ){
                                return real ? src.replace(re,function(all,name){
                                                  return content[i][name];
                                              }) : src;
                                }
                              );

              for(i=0; i<content.length;i++){
                        var rendered_template = template;
                        rendered_template=rendered_template.replace(new RegExp('\\$row\\$','g'),""+i);
                        var tpl = rendered_template;
                        var tokens = tokenizer.parse(tpl);
                        output += tokens.join('');
              }
              output += '</table>' ;   
              return output;    
            },
            resetTemplate: function(format,type){
                // calculate out-of-the box template
                   var template="";
                   var i=0;
                   var formatList = JSON.parse(format);
                   if(type=='horizontal'){
                         template +="<tr>";
                         for(i=0; i<formatList.length; i++){
                             template +='<td data-cell="$row$,'+i+'">';
                             template += "$"+formatList[i].variable+"$";
                             template +="</td>";
                         }
                         template +="</tr>";
                   } else {
                       // vertical                         
                         for(i=0; i<formatList.length; i++){
                             template +="<tr>";
                             template +="<td><b>";
                             template +=formatList[i].title;
                             template +="</td></b>";
                             template +="<td>";
                             template += "$"+formatList[i].variable+"$";
                             template +="</td>";
                             template +="</tr>";
                         }                         
                   }
                   return template;
            },
            resetFormat: function(sqlData) {
                // calculate the out-of-the box format for the given query
                if ((!!sqlData) && (Array.isArray(sqlData))) {
                    var format = [];
                    var i = 0;
                    for (var key in sqlData[0]) {
                        var temp={};
                        temp={variable:key,title:key,format:"%s"};
                        format.push(temp);
                        // by default the format is the string format
                    }
                }
                return JSON.stringify(format);
            },
            formatData: function(sqlData, format) {
                var formatList = JSON.parse(format);
                var out = [];
                var i, j;
                if ((!!sqlData) && (Array.isArray(sqlData))) {
                    for (i = 0; i < sqlData.length; i++) {
                        var record = {};
                        for (j = 0; j < formatList.length; j++) {
                            record[formatList[j].variable] = this.sprintf(formatList[j].format, sqlData[i][formatList[j].variable]);
                        }
                        out.push(record);
                    }
                }
                return out;
            },
            findckrlite: function(name){                
                var instances = this.editor.widgets.instances
                if((instances!=undefined)&&(instances!=null)){                     
                      for(var i in instances){
                          if(instances[i].name=='ckrlite') {
                               if(instances[i].data.name==name) {
                                    return instances[i]; 
                               }     
                          }       
                      }      
                }
                return null
            },
            masterList: function(){
                var instances = this.editor.widgets.instances
                if((instances!=undefined)&&(instances!=null)){
                      var select = [];
                      for(var i in instances){
                          if(instances[i].name=='ckrlite'){
                              if(instances[i].data.name!=this.data.name){
                                    select.push([instances[i].data.name, instances[i].data.name]);
                              }
                          }  
                      }
                      return select;                                  
                }       
            },
            getContent: function(){
                  // test if master mode setData
               var path=this.editor.ckrlite[this.data.name].select;
               if((path!=undefined)&&(!!path)){   
                  var master = this.editor.ckrlite[this.data.name].master;                 
                  if((master!=undefined) &&
                     (master!=null) &&
                     (master!="") &&
                     (master!="-1")){
                     // this widget is master linked
                     // get the column name of master from select
                     var n = path.lastIndexOf("/");
                     var column_name = path.substring(0,n);
                     var m = column_name.lastIndexOf("/");
                     column_name = column_name.substring(m+1);
                     var master_widget = this.findckrlite(this.editor.ckrlite[this.data.name].master);
                     var index = this.editor.ckrlite[master_widget.data.name].index;
                     if((index==undefined)||(index==null)){
                         // set the index to 0,0
                         index=this.editor.ckrlite[master_widget.data.name].index="0,0";
                     }
                     var content = this.editor.ckrlite[master_widget.data.name].content;
                     if((master_widget!=undefined)&&(master_widget!=null)){                        
                        
                           if((content!=undefined)&&(content!=null)){
                              content = JSON.parse(content);
                              if((content!=undefined)&&(content!=null)){
                                 var index = parseInt(index.split()[0],10);
                                 if((!!content[index])&&(content[index][column_name]!=undefined)&&(content[index][column_name]!=null)){                                    
                                     path = path.substring(0,n+1)+content[index][column_name];
                                 }
                              }
                           }                           
                          
                     }
                  }
                  if(!!this.editor.ckrlite[this.data.name].page){
                     path += "?limit="+this.editor.ckrlite[this.data.name].page
                  } else {
                     path += "?limit=10";
                  }
                  if(!!this.editor.ckrlite[this.data.name].offset){
                     path+="&offset="+this.editor.ckrlite[this.data.name].offset;
                  }                 
                  var url = "/ArrestDB/ArrestDB.php" + path;
                  var sqlData = CKEDITOR.restajax.getjson(url);
                  return sqlData;
               } else return {};
            },
            event: function(msg,data){
                console.log(msg+" "+" event:"+data.event+" from:"+data.widget.data.name+" to:"+this.data.name+" "+Date.now());
                // msg = master (must be unique) which published the event
                // data = {event:'event',widget:widget}            
                if((data.event=='indexChange')||(data.event=='contentChange')){
                    var widget = this;
                    // reset index
                    this.editor.ckrlite[this.data.name].index="0,0";
                    // reset the offset
                    this.editor.ckrlite[this.data.name].offset=0;
                    // recompute content
                    var sqlData = widget.getContent();
                    // widget.setData('content',JSON.stringify(sqlData));
                    this.editor.ckrlite[this.data.name].content=JSON.stringify(sqlData);
                    // widget.fire('contentChange',this);
					widget.setData('refresh',"0");
					widget.setData('refresh',"1");									
                    widget.PubSub.publish(this.data.name,{event:'contentChange',widget:widget});
                }                
            },
            insertCss: function ( code ) {
                        var style = document.createElement('style');
                        style.type = 'text/css';

                        if (style.styleSheet) {
                                    // IE
                                    style.styleSheet.cssText = code;
                        } else {
                                    // Other browsers
                                    style.innerHTML = code;
                        }

                        document.getElementsByTagName("head")[0].appendChild( style );
            },            
            sprintf: function(format) {
                // Check for format definition
                if (typeof format != 'string') {
                    throw "sprintf: The first arguments need to be a valid format string.";
                }
                
                /**
                 * Define the regex to match a formating string
                 * The regex consists of the following parts:
                 * percent sign to indicate the start
                 * (optional) sign specifier
                 * (optional) padding specifier
                 * (optional) alignment specifier
                 * (optional) width specifier
                 * (optional) precision specifier
                 * type specifier:
                 *  % - literal percent sign
                 *  b - binary number
                 *  c - ASCII character represented by the given value
                 *  d - signed decimal number
                 *  f - floating point value
                 *  o - octal number
                 *  s - string
                 *  x - hexadecimal number (lowercase characters)
                 *  X - hexadecimal number (uppercase characters)
                 */
                var r = new RegExp(/%(\+)?([0 ]|'(.))?(-)?([0-9]+)?(\.([0-9]+))?([%bcdfosxX])/g);
                
                /**
                 * Each format string is splitted into the following parts:
                 * 0: Full format string
                 * 1: sign specifier (+)
                 * 2: padding specifier (0/<space>/'<any char>)
                 * 3: if the padding character starts with a ' this will be the real
                 *    padding character
                 * 4: alignment specifier
                 * 5: width specifier
                 * 6: precision specifier including the dot
                 * 7: precision specifier without the dot
                 * 8: type specifier
                 */
                var parts = [];
                var paramIndex = 1;
                while (part = r.exec(format)) {
                    // Check if an input value has been provided, for the current
                    // format string (no argument needed for %%)
                    if ((paramIndex >= arguments.length) && (part[8] != '%')) {
                        throw "sprintf: At least one argument was missing.";
                    }
                    
                    parts[parts.length] = {
                        /* beginning of the part in the string */
                        begin: part.index,
                        /* end of the part in the string */
                        end: part.index + part[0].length,
                        /* force sign */
                        sign: (part[1] == '+'),
                        /* is the given data negative */
                        negative: (parseFloat(arguments[paramIndex]) < 0) ? true : false,
                        /* padding character (default: <space>) */
                        padding: (part[2] == undefined) ? (' ')/* default */ : ((part[2].substring(0, 1) == "'") ? (part[3])/* use special char */ : (part[2])/* use normal <space> or zero */),
                        /* should the output be aligned left?*/
                        alignLeft: (part[4] == '-'),
                        /* width specifier (number or false) */
                        width: (part[5] != undefined) ? part[5] : false,
                        /* precision specifier (number or false) */
                        precision: (part[7] != undefined) ? part[7] : false,
                        /* type specifier */
                        type: part[8],
                        /* the given data associated with this part converted to a string */
                        data: (part[8] != '%') ? String(arguments[paramIndex++]) : false
                    };
                }
                
                var newString = "";
                var start = 0;
                // Generate our new formated string
                for (var i = 0; i < parts.length; ++i) {
                    // Add first unformated string part
                    newString += format.substring(start, parts[i].begin);
                    
                    // Mark the new string start
                    start = parts[i].end;
                    
                    // Create the appropriate preformat substitution
                    // This substitution is only the correct type conversion. All the
                    // different options and flags haven't been applied to it at this
                    // point
                    var preSubstitution = "";
                    switch (parts[i].type) {
                    case '%':
                        preSubstitution = "%";
                        break;
                    case 'b':
                        preSubstitution = Math.abs(parseInt(parts[i].data)).toString(2);
                        break;
                    case 'c':
                        preSubstitution = String.fromCharCode(Math.abs(parseInt(parts[i].data)));
                        break;
                    case 'd':
                        preSubstitution = String(Math.abs(parseInt(parts[i].data)));
                        break;
                    case 'f':
                        preSubstitution = (parts[i].precision === false) ? (String((Math.abs(parseFloat(parts[i].data))))) : (Math.abs(parseFloat(parts[i].data)).toFixed(parts[i].precision));
                        break;
                    case 'o':
                        preSubstitution = Math.abs(parseInt(parts[i].data)).toString(8);
                        break;
                    case 's':
                        preSubstitution = parts[i].data.substring(0, parts[i].precision ? parts[i].precision : parts[i].data.length);
                        /* Cut if precision is defined */
                        break;
                    case 'x':
                        preSubstitution = Math.abs(parseInt(parts[i].data)).toString(16).toLowerCase();
                        break;
                    case 'X':
                        preSubstitution = Math.abs(parseInt(parts[i].data)).toString(16).toUpperCase();
                        break;
                    default:
                        throw 'sprintf: Unknown type "' + parts[i].type + '" detected. This should never happen. Maybe the regex is wrong.';
                    }
                    
                    // The % character is a special type and does not need further processing
                    if (parts[i].type == "%") {
                        newString += preSubstitution;
                        continue;
                    }
                    
                    // Modify the preSubstitution by taking sign, padding and width
                    // into account
                    
                    // Pad the string based on the given width
                    if (parts[i].width != false) {
                        // Padding needed?
                        if (parts[i].width > preSubstitution.length) {
                            var origLength = preSubstitution.length;
                            for (var j = 0; j < parts[i].width - origLength; ++j) {
                                preSubstitution = (parts[i].alignLeft == true) ? (preSubstitution + parts[i].padding) : (parts[i].padding + preSubstitution);
                            }
                        }
                    }
                    
                    // Add a sign symbol if neccessary or enforced, but only if we are
                    // not handling a string
                    if (parts[i].type == 'b' || parts[i].type == 'd' || parts[i].type == 'o' || parts[i].type == 'f' || parts[i].type == 'x' || parts[i].type == 'X') {
                        if (parts[i].negative == true) {
                            preSubstitution = "-" + preSubstitution;
                        } else if (parts[i].sign == true) {
                            preSubstitution = "+" + preSubstitution;
                        }
                    }
                    
                    // Add the substitution to the new string
                    newString += preSubstitution;
                }
                
                // Add the last part of the given format string, which may still be there
                newString += format.substring(start, format.length);
                
                return newString;
            }
        });
    }
});
