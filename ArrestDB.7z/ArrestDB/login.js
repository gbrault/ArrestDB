CKEDITOR.dialog.add( 'testOnly', function( editor ) {
    return {
        title:          'Test Dialog',
        resizable:      CKEDITOR.DIALOG_RESIZE_BOTH,
        minWidth:       500,
        minHeight:      400,
        contents: [
            {
                id:         'tab1',
                label:      'First Tab',
                title:      'First Tab Title',
                accessKey:  'Q',
                elements: [
                    {
                        type:           'text',
                        label:          'Test Text 1',
                        id:             'testText1',
                        'default':      'hello world!'
                    },
                    {
    					type: 'text',
    					id: 'name',
    					label: 'Your name',
    					'default': '',
    					validate: function(api) {
        						if ( !this.getValue() ) {
        							editor.say('Name cannot be empty.');
            						return false;
        						}
    					}
					}
                ]
            },
            {
                id:         'tab2',
                label:      'Second Tab',
                title:      'Second Tab Title',
                accessKey:  'R',
                elements: [
                    {
                        type:           'password',
                        label:          'Test Text 2',
                        id:             'testText2',
                        'default':      'hello world 2!'
                    },
                    {
    					type: 'text',
    					id: 'name2',
    					label: 'Your name 2',
    					'default': '',
    					validate: function(api) {
        						if ( !this.getValue() ) {
        							editor.say('Name cannot be empty.');
            						return false;
        						}
    					}
					}
                ]
            }            
        ]
    };
} );

CKEDITOR.dialog.add( 'login', function( editor ) {
    return {
        title:          'Login & Account Management Dialogs',
        resizable:      CKEDITOR.DIALOG_RESIZE_BOTH,
        minWidth:       500,
        minHeight:      400,
        contents: [
            {
                id:         'login',
                label:      'login',
                title:      'Login Dialog',
                accessKey:  'L',
                elements: [
                    {
    					type: 'userid',
    					id: 'userid',
    					label: 'Your User ID',
    					'default': '',
    					validate: function(api) {
        						if ( !this.getValue() ) {
        							editor.say('User ID cannot be empty.');
            						return false;
        						}
    					}
					}/*,
					{
    					type: 'password',
    					id: 'password',
    					label: 'Your password',
    					'default': '',
    					validate: function(api) {
        						if ( !this.getValue() ) {
        							editor.say('Password cannot be empty.');
            						return false;
        						}
    					}
					},
					{
    					type: 'button',
    					id: 'buttonId',
    					label: 'Login',
    					title: 'Click to Login',
    					onClick: function() {
        					// this = CKEDITOR.ui.dialog.button
        					CKEDITOR.restajax.getjson();
    					}
					}*/
                ]
            },
            {
                id:         'management',
                label:      'Management',
                title:      'Account management',
                accessKey:  'M',
                elements: [
                    {
                        type:           'text',
                        label:          'First Name',
                        id:             'firstname',
                        'default':      ''
                    },
                    {
    					type: 'text',
    					id: 'lastname',
    					label: 'Last Name',
    					'default': '',
    					validate: function(api) {
        						if ( !this.getValue() ) {
        							editor.say('Name cannot be empty.');
            						return false;
        						}
    					}
					},
                    {
    					type: 'text',
    					id: 'email',
    					label: 'email',
    					'default': '',
    					validate: function(api) {
        						if ( !this.getValue() ) {
        							editor.say('email cannot be empty.');
            						return false;
        						}
    					}
					}
                ]
            }            
        ]
    };
} );