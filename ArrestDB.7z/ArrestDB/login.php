<?php
session_start();
require('security.php');
require('WebClient.php');
require 'aes.class.php';     // AES PHP implementation
require 'aesctr.class.php';  // AES Counter Mode implementation 
/*
* Get request action=getuser,user=<encrypted>, password=<encrypted>
* http://<server>/login.php?action=getuser&user=abqrz05?3o=&password=lu89ezqr6=
* $_SESSION["after"]= encoding aes password
*/
if(strcasecmp($_SERVER['REQUEST_METHOD'], 'GET') === 0){
	if($_GET['action']=='getuser'){
		$user = AesCtr::decrypt($_GET['user'], $_SESSION["after"], 256);
		$password = AesCtr::decrypt($_GET['password'], $_SESSION["after"], 256);
	}
}
header('Content-Type: application/json');
$result = json_encode(['status' => 'OK','key'=>$_SESSION["after"]]);
echo $result;
?>