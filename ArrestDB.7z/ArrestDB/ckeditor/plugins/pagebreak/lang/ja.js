/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'pagebreak', 'ja', {
	alt: '改ページ',
	toolbar: '印刷の為に改ページ挿入'
} );
