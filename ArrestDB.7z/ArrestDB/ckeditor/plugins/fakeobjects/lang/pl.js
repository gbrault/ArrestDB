/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'fakeobjects', 'pl', {
	anchor: 'Kotwica',
	flash: 'Animacja Flash',
	hiddenfield: 'Pole ukryte',
	iframe: 'IFrame',
	unknown: 'Nieznany obiekt'
} );
